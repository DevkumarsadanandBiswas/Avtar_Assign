"""
tts_engine.py
─────────────
Text-to-Speech abstraction layer.

Supported engines:
  edge    — Microsoft Edge TTS (free, online, richest voice styles)
  gtts    — Google Text-to-Speech (free, online, limited style control)
  pyttsx3 — Offline TTS via system voices (no style control)

Usage
-----
    from tts_engine import synthesize
    path = synthesize("Hello world", emotion="happy", out_path="outputs/audio.wav")
"""

from __future__ import annotations

import asyncio
import os
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Optional

# ─── Edge TTS voice table ────────────────────────────────────────────────────
# Maps (style) → Edge TTS voice name (en-US, high quality)
_EDGE_VOICE = "en-US-AriaNeural"          # default — supports many styles
_EDGE_STYLE_MAP = {
    "neutral":   "general",
    "firm":      "empathetic",
    "cheerful":  "cheerful",
    "sad":       "sad",
    "angry":     "angry",
    "shouting":  "shouting",
    "empathetic":"empathetic",
}

# ─── Speed/pitch helpers ──────────────────────────────────────────────────────
def _rate_str(speed: float) -> str:
    """Convert float speed to Edge TTS rate string, e.g. '+10%' or '-5%'."""
    pct = int(round((speed - 1.0) * 100))
    return f"+{pct}%" if pct >= 0 else f"{pct}%"

def _pitch_str(pitch: int) -> str:
    """Convert semitone int to Edge TTS pitch string, e.g. '+2Hz'."""
    hz = pitch * 5   # approximate: 1 semitone ≈ 5 Hz for this purpose
    return f"+{hz}Hz" if hz >= 0 else f"{hz}Hz"


# ─── Edge TTS synthesis ───────────────────────────────────────────────────────
async def _edge_synthesize_async(
    text: str,
    out_path: str,
    voice_style: str = "general",
    speed: float = 1.0,
    pitch: int = 0,
) -> None:
    try:
        import edge_tts
    except ImportError:
        raise RuntimeError("edge-tts not installed. Run: pip install edge-tts")

    style = _EDGE_STYLE_MAP.get(voice_style, "general")
    communicate = edge_tts.Communicate(
        text=text,
        voice=_EDGE_VOICE,
        rate=_rate_str(speed),
        pitch=_pitch_str(pitch),
    )
    # Write to mp3 first (Edge TTS native format), convert later if needed
    tmp_mp3 = out_path.replace(".wav", ".mp3") if out_path.endswith(".wav") else out_path
    await communicate.save(tmp_mp3)

    # Convert mp3 → wav if requested
    if out_path.endswith(".wav") and tmp_mp3 != out_path:
        _ffmpeg_convert(tmp_mp3, out_path)
        os.remove(tmp_mp3)


def _edge_synthesize(
    text: str,
    out_path: str,
    voice_style: str = "general",
    speed: float = 1.0,
    pitch: int = 0,
) -> None:
    """Blocking wrapper around the async Edge TTS call."""
    asyncio.run(_edge_synthesize_async(text, out_path, voice_style, speed, pitch))


# ─── gTTS fallback synthesis ─────────────────────────────────────────────────
def _gtts_synthesize(text: str, out_path: str, speed: float = 1.0) -> None:
    try:
        from gtts import gTTS
    except ImportError:
        raise RuntimeError("gtts not installed. Run: pip install gtts")

    slow = speed < 0.9
    tts = gTTS(text=text, lang="en", slow=slow)
    tmp_mp3 = out_path.replace(".wav", "_gtts.mp3")
    tts.save(tmp_mp3)
    if out_path.endswith(".wav"):
        _ffmpeg_convert(tmp_mp3, out_path)
        os.remove(tmp_mp3)
    else:
        os.rename(tmp_mp3, out_path)


# ─── pyttsx3 offline fallback ─────────────────────────────────────────────────
def _pyttsx3_synthesize(text: str, out_path: str, speed: float = 1.0) -> None:
    try:
        import pyttsx3
    except ImportError:
        raise RuntimeError("pyttsx3 not installed. Run: pip install pyttsx3")

    engine = pyttsx3.init()
    base_rate = engine.getProperty("rate")  # typically 200 wpm
    engine.setProperty("rate", int(base_rate * speed))
    engine.save_to_file(text, out_path)
    engine.runAndWait()


# ─── FFmpeg helper ────────────────────────────────────────────────────────────
def _ffmpeg_convert(src: str, dst: str) -> None:
    result = subprocess.run(
        ["ffmpeg", "-y", "-i", src, dst],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg conversion failed:\n{result.stderr}")


# ─── Public API ───────────────────────────────────────────────────────────────
def synthesize(
    text: str,
    emotion: str = "neutral",
    out_path: str = "outputs/tts_audio.wav",
    provider: str = "edge",
    tts_params: Optional[dict] = None,
) -> str:
    """
    Convert text to speech using the specified provider.

    Parameters
    ----------
    text       : Text to synthesize.
    emotion    : Emotion label — used to look up TTS parameters if tts_params
                 is not provided directly.
    out_path   : Output audio file path (.wav or .mp3).
    provider   : 'edge' | 'gtts' | 'pyttsx3'
    tts_params : Optional dict with keys voice_style, speed, pitch.
                 If None, loads from emotion_mapping.json via ConversationEngine.

    Returns
    -------
    out_path — the path where the audio was saved.
    """
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)

    # Load TTS params from emotion map if not supplied
    if tts_params is None:
        from conversation_engine import EMOTION_MAP
        cfg = EMOTION_MAP.get(emotion, {})
        tts_params = {
            "voice_style": cfg.get("voice_style", "neutral"),
            "speed": cfg.get("speed", 1.0),
            "pitch": cfg.get("pitch", 0),
        }

    voice_style = tts_params.get("voice_style", "neutral")
    speed = float(tts_params.get("speed", 1.0))
    pitch = int(tts_params.get("pitch", 0))

    t0 = time.time()
    provider = provider.lower()

    if provider == "edge":
        try:
            _edge_synthesize(text, out_path, voice_style=voice_style, speed=speed, pitch=pitch)
            print(f"[TTS] Edge TTS → {out_path}  ({time.time()-t0:.2f}s)")
        except Exception as exc:
            print(f"[TTS] Edge TTS failed ({exc}). Trying gTTS fallback...")
            _gtts_synthesize(text, out_path, speed=speed)
            print(f"[TTS] gTTS fallback → {out_path}  ({time.time()-t0:.2f}s)")

    elif provider == "gtts":
        _gtts_synthesize(text, out_path, speed=speed)
        print(f"[TTS] gTTS → {out_path}  ({time.time()-t0:.2f}s)")

    elif provider == "pyttsx3":
        _pyttsx3_synthesize(text, out_path, speed=speed)
        print(f"[TTS] pyttsx3 (offline) → {out_path}  ({time.time()-t0:.2f}s)")

    else:
        raise ValueError(f"Unknown TTS provider '{provider}'. Choose: edge, gtts, pyttsx3")

    return out_path
