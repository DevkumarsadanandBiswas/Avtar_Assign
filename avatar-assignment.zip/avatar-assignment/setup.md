# Setup Guide — AI Avatar Conversation Pipeline

## System Requirements

| Requirement | Minimum | Recommended |
|---|---|---|
| OS | Ubuntu 20.04 / macOS 12 / Windows 10 WSL2 | Ubuntu 22.04 |
| Python | 3.10 | 3.10.x |
| RAM | 8 GB | 16 GB |
| GPU | None (CPU mode works) | NVIDIA RTX 3060+ (CUDA 11.8+) |
| Disk | 10 GB | 20 GB |
| FFmpeg | Required | Required |

> **Windows users**: Use WSL2 (Ubuntu 22.04). Native Windows is not recommended for SadTalker.

---

## Step 1 — Clone This Repository

```bash
git clone <your-repo-url> avatar-assignment
cd avatar-assignment
```

---

## Step 2 — Install FFmpeg

FFmpeg is required for all audio/video processing.

**Ubuntu / Debian**
```bash
sudo apt update && sudo apt install -y ffmpeg
```

**macOS (Homebrew)**
```bash
brew install ffmpeg
```

**Windows (WSL2)**
```bash
sudo apt update && sudo apt install -y ffmpeg
```

**Verify**
```bash
ffmpeg -version
# Expected: ffmpeg version 4.x or 5.x ...
```

---

## Step 3 — Create Python Virtual Environment

```bash
python3.10 -m venv venv
source venv/bin/activate        # Linux / macOS
# venv\Scripts\activate         # Windows (if not using WSL2)
```

---

## Step 4 — Install Python Dependencies

**CPU only** (slower inference, no GPU needed):
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

**CUDA GPU (recommended for real-time generation)**:
```bash
# Install PyTorch with CUDA 11.8 first
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
# Then install the rest
pip install -r requirements.txt
```

> **Note:** If you see `cmake` missing during `face-alignment` install:
> ```bash
> sudo apt install cmake
> ```

---

## Step 5 — Install SadTalker

SadTalker is the talking-head avatar model used in this project.

**5a. Clone SadTalker inside the project folder**
```bash
git clone https://github.com/OpenTalker/SadTalker.git SadTalker
```

**5b. Install SadTalker's additional dependencies**
```bash
cd SadTalker
pip install -r requirements.txt
cd ..
```

**5c. Download pretrained model weights**

SadTalker provides a download script:

```bash
cd SadTalker
# Automatic download script (downloads ~3 GB of weights)
bash scripts/download_models.sh
cd ..
```

If the script fails, manually download from:
- **Google Drive**: https://drive.google.com/drive/folders/1Wd88VDoLhVzYsQ30_qDVluQr_Mx7l4sQ
- **Baidu Netdisk**: (see SadTalker README for link)

Expected directory structure after download:
```
SadTalker/
├── checkpoints/
│   ├── SadTalker_V0.0.2_256.safetensors
│   ├── SadTalker_V0.0.2_512.safetensors
│   └── ...
├── gfpgan/
│   └── weights/
│       ├── GFPGANv1.4.pth
│       └── ...
└── inference.py
```

**5d. Verify SadTalker works**
```bash
cd SadTalker
python inference.py \
    --driven_audio examples/driven_audio/bus_chinese.wav \
    --source_image examples/source_image/full_body_1.png \
    --result_dir /tmp/sadtalker_test \
    --still \
    --preprocess crop \
    --size 256
cd ..
```
A `.mp4` should appear in `/tmp/sadtalker_test/`.

> **CPU mode note**: On CPU, generation takes 3–10 minutes per video. On an RTX 3060, it takes 15–60 seconds.

---

## Step 6 — (Optional) Set OpenAI API Key

For LLM-generated responses instead of the rule-based fallback:

```bash
export OPENAI_API_KEY="sk-..."
```

Or use a local Ollama server:
```bash
export OPENAI_API_KEY="ollama"
export OPENAI_BASE_URL="http://localhost:11434/v1"
```

The pipeline works **without any API key** using built-in rule-based responses.

---

## Step 7 — Add a Sample Avatar Image

Place an AI-generated or open-licence portrait in `samples/avatar.jpg`.

**Free AI portrait sources** (no copyright issues):
- https://this-person-does-not-exist.com  (refresh for new face)
- https://generated.photos/faces
- https://picsum.photos (abstract, not a face)

Requirements: minimum 256×256 pixels, frontal face, JPEG or PNG.

---

## Step 8 — Verify the Full Setup

```bash
# Check Python imports
python -c "import cv2, torch, edge_tts, fastapi; print('OK')"

# Check FFmpeg
ffmpeg -version

# Run conversation demo (no GPU needed)
python generate_avatar.py --conversation-demo

# Run TTS demo
python generate_avatar.py --tts-demo

# Run full pipeline (requires SadTalker weights)
python generate_avatar.py \
    --image samples/avatar.jpg \
    --user-text "Why are you silent?" \
    --emotion confident \
    --output outputs/avatar_response.mp4
```

---

## Known Setup Issues and Fixes

| Error | Fix |
|---|---|
| `No module named 'face_alignment'` | `pip install face-alignment` |
| `cmake not found` (face-alignment build) | `sudo apt install cmake` |
| `ffmpeg: command not found` | Install FFmpeg (Step 2) |
| `CUDA out of memory` | Add `--size 256` or use `--device cpu` |
| SadTalker `ModuleNotFoundError: basicsr` | `pip install basicsr` |
| SadTalker `No such file: checkpoints/` | Re-run `bash scripts/download_models.sh` |
| `edge-tts` timeout | Check internet connection; use `--tts-provider gtts` as fallback |
| `openai.AuthenticationError` | Set `OPENAI_API_KEY`; or omit for rule-based fallback |

---

## Environment Details (reference — fill in yours)

```
OS          : Ubuntu 22.04.3 LTS
Python      : 3.10.12
CUDA        : 11.8 (if GPU used)
GPU         : NVIDIA RTX 3060 12 GB (if applicable)
FFmpeg      : 5.1.3
SadTalker   : commit abc1234 (main branch, 2024-01)
edge-tts    : 6.1.9
torch       : 2.0.1+cu118
```

---

## Notes on Hardcoded Paths

This project contains **no hardcoded absolute paths**. All paths are relative to the project root or passed as CLI arguments. The `SADTALKER_ROOT` environment variable and `--sadtalker-root` CLI flag are provided for flexible deployment.
