"""
conversation_engine.py
──────────────────────
Handles AI response generation, emotion assignment, and conversation logging
for the AI Avatar Conversation pipeline.

Supports:
  - OpenAI-compatible API (GPT-4o, GPT-3.5, local Ollama, LM Studio)
  - Rule-based fallback (zero API key required)
  - Conversation history saved to outputs/conversation_log.json
"""

from __future__ import annotations

import json
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

# ─── Optional OpenAI import ──────────────────────────────────────────────────
try:
    from openai import OpenAI
    _OPENAI_AVAILABLE = True
except ImportError:
    _OPENAI_AVAILABLE = False

# ─── Load emotion map ────────────────────────────────────────────────────────
_EMOTION_MAP_PATH = Path(__file__).parent / "emotion_mapping.json"

def load_emotion_map() -> dict:
    if _EMOTION_MAP_PATH.exists():
        with open(_EMOTION_MAP_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return {k: v for k, v in data.items() if not k.startswith("_")}
    return {}

EMOTION_MAP = load_emotion_map()
VALID_EMOTIONS = list(EMOTION_MAP.keys())


# ─── Rule-based fallback responses ───────────────────────────────────────────
_FALLBACK_RESPONSES: dict[str, list[str]] = {
    "who are you": [
        "I am an avatar — a reflection of thought given voice and form.",
        "I am the one who listens before speaking.",
        "I am neither more nor less than what you see before you.",
    ],
    "why do you look serious": [
        "Gravity is not sadness. I am simply present.",
        "Because some truths deserve a still face to carry them.",
        "Seriousness is my way of showing that I am paying attention.",
    ],
    "tell me something emotional": [
        "The most honest thing I know is this: everyone is carrying something they have never said aloud.",
        "Loss is not just the absence of people. It is the absence of the version of yourself that existed with them.",
        "Sometimes the bravest thing a person can do is simply stay.",
    ],
    "why are you angry": [
        "I am not angry. I am disappointed — and disappointment runs quieter and deeper.",
        "Anger fades. What I carry is a sharper kind of knowing.",
        "I am not angry. I am precise.",
    ],
    "why are you silent": [
        "Silence is not emptiness. It is the space where honesty gathers before it speaks.",
        "I was listening. That is not the same as being absent.",
        "Some answers are worth the wait.",
    ],
    "default": [
        "Words are not the beginning of thought. They are the end of it.",
        "I speak only when silence becomes heavier than truth.",
        "Not every question deserves an answer immediately. But this one does.",
        "There is more in what is unsaid than in what is spoken.",
        "I do not have a simple answer. But I have an honest one.",
    ],
}

def _rule_based_response(user_text: str, emotion: str) -> str:
    """Return a context-aware fallback response without any API call."""
    lower = user_text.lower().strip()
    for key, candidates in _FALLBACK_RESPONSES.items():
        if key != "default" and key in lower:
            idx = hash(user_text) % len(candidates)
            return candidates[idx]

    tone = EMOTION_MAP.get(emotion, {}).get("prompt_tone", "calm")
    defaults = _FALLBACK_RESPONSES["default"]
    idx = hash(user_text + emotion) % len(defaults)
    base = defaults[idx]
    if "confident" in tone:
        return base + " That much I know for certain."
    if "melancholic" in tone or "sad" in tone:
        return base + " And that weight never quite lifts."
    if "playful" in tone:
        return base + " Or maybe I am just enjoying the mystery."
    return base


# ─── LLM-based response ──────────────────────────────────────────────────────
def _llm_response(
    user_text: str,
    emotion: str,
    history: list[dict],
    api_key: str,
    base_url: Optional[str],
    model: str,
) -> str:
    """Call an OpenAI-compatible API to generate a response."""
    if not _OPENAI_AVAILABLE:
        raise RuntimeError("openai package not installed. Run: pip install openai")

    tone = EMOTION_MAP.get(emotion, {}).get("prompt_tone", "calm and measured")
    system_prompt = (
        "You are a thoughtful, expressive AI avatar. "
        f"Your current emotional state is: {emotion}. "
        f"Speak in a tone that is {tone}. "
        "Keep your response to 1–3 sentences. "
        "Be philosophical and articulate. Never break character."
    )

    messages = [{"role": "system", "content": system_prompt}]
    for turn in history[-6:]:  # keep last 3 turns for context
        messages.append({"role": "user", "content": turn["user"]})
        messages.append({"role": "assistant", "content": turn["response"]})
    messages.append({"role": "user", "content": user_text})

    kwargs = {"api_key": api_key, "timeout": 30.0}
    if base_url:
        kwargs["base_url"] = base_url

    client = OpenAI(**kwargs)
    completion = client.chat.completions.create(
        model=model,
        messages=messages,
        max_tokens=150,
        temperature=0.8,
    )
    return completion.choices[0].message.content.strip()


# ─── Auto-emotion detection ───────────────────────────────────────────────────
def detect_emotion(user_text: str) -> str:
    """Heuristically guess an appropriate emotion from user input."""
    lower = user_text.lower()
    if any(w in lower for w in ["angry", "mad", "furious", "rage"]):
        return "angry"
    if any(w in lower for w in ["sad", "cry", "depressed", "upset", "hurt"]):
        return "sad"
    if any(w in lower for w in ["happy", "joy", "laugh", "funny", "great"]):
        return "happy"
    if any(w in lower for w in ["serious", "silent", "quiet", "intense"]):
        return "intense"
    if any(w in lower for w in ["tease", "joke", "play", "witty"]):
        return "teasing"
    if any(w in lower for w in ["sure", "certain", "confident", "strong"]):
        return "confident"
    return "neutral"


# ─── Main ConversationEngine class ───────────────────────────────────────────
class ConversationEngine:
    """
    Orchestrates response generation, emotion handling, and conversation logging.

    Parameters
    ----------
    log_path : str
        Path to the JSON conversation log file.
    api_key : str, optional
        OpenAI-compatible API key. If empty, falls back to rule-based responses.
    base_url : str, optional
        Override API base URL (e.g. http://localhost:11434/v1 for Ollama).
    model : str
        Model name. Defaults to gpt-4o-mini.
    """

    def __init__(
        self,
        log_path: str = "outputs/conversation_log.json",
        api_key: str = "",
        base_url: Optional[str] = None,
        model: str = "gpt-4o-mini",
    ):
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.base_url = base_url or os.environ.get("OPENAI_BASE_URL", None)
        self.model = model
        self.history: list[dict] = self._load_history()

    # ── History I/O ──────────────────────────────────────────────────────────
    def _load_history(self) -> list[dict]:
        if self.log_path.exists():
            try:
                with open(self.log_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return []
        return []

    def _save_history(self) -> None:
        with open(self.log_path, "w", encoding="utf-8") as f:
            json.dump(self.history, f, indent=2, ensure_ascii=False)

    # ── Core respond method ───────────────────────────────────────────────────
    def respond(
        self,
        user_text: str,
        emotion: str = "neutral",
        audio_path: str = "",
        video_path: str = "",
    ) -> dict:
        """
        Generate an avatar response for user_text with the given emotion.

        Returns a dict with keys: user, response, emotion, audio_path,
        video_path, generation_time, timestamp.
        """
        emotion = emotion.lower().strip()
        if emotion not in VALID_EMOTIONS:
            print(f"[warn] Unknown emotion '{emotion}', falling back to 'neutral'")
            emotion = "neutral"

        t0 = time.time()
        method_used = "rule_based"

        if self.api_key and _OPENAI_AVAILABLE:
            try:
                response_text = _llm_response(
                    user_text, emotion, self.history,
                    self.api_key, self.base_url, self.model
                )
                method_used = f"llm:{self.model}"
            except Exception as exc:
                print(f"[warn] LLM call failed ({exc}). Using rule-based fallback.")
                response_text = _rule_based_response(user_text, emotion)
        else:
            response_text = _rule_based_response(user_text, emotion)

        generation_time = round(time.time() - t0, 3)

        entry = {
            "turn": len(self.history) + 1,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "user": user_text,
            "response": response_text,
            "emotion": emotion,
            "emotion_config": EMOTION_MAP.get(emotion, {}),
            "audio_path": audio_path,
            "video_path": video_path,
            "generation_time_response_seconds": generation_time,
            "method": method_used,
        }
        self.history.append(entry)
        self._save_history()
        return entry

    # ── Convenience helpers ───────────────────────────────────────────────────
    def get_tts_params(self, emotion: str) -> dict:
        """Return TTS parameters (speed, pitch, voice_style) for an emotion."""
        cfg = EMOTION_MAP.get(emotion, EMOTION_MAP.get("neutral", {}))
        return {
            "voice_style": cfg.get("voice_style", "neutral"),
            "speed": cfg.get("speed", 1.0),
            "pitch": cfg.get("pitch", 0),
        }

    def print_history(self) -> None:
        """Pretty-print the conversation history to stdout."""
        for entry in self.history:
            print(f"\n[Turn {entry['turn']}] {entry['timestamp']}")
            print(f"  User    : {entry['user']}")
            print(f"  Avatar  : {entry['response']}")
            print(f"  Emotion : {entry['emotion']}")


# ─── CLI demo ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Run a demo conversation session")
    parser.add_argument("--api-key", default="", help="OpenAI API key (optional)")
    parser.add_argument("--model", default="gpt-4o-mini", help="Model name")
    parser.add_argument("--log", default="outputs/conversation_log.json")
    args = parser.parse_args()

    engine = ConversationEngine(log_path=args.log, api_key=args.api_key, model=args.model)

    sample_turns = [
        ("Who are you?", "neutral"),
        ("Why do you look serious?", "intense"),
        ("Tell me something emotional in one sentence.", "sad"),
    ]

    print("\n=== AI Avatar Conversation Demo ===\n")
    for user_msg, emotion in sample_turns:
        print(f"User    : {user_msg}")
        entry = engine.respond(user_msg, emotion=emotion)
        print(f"Avatar  : {entry['response']}")
        print(f"Emotion : {entry['emotion']}")
        print(f"Method  : {entry['method']}")
        print("-" * 50)

    print(f"\nConversation log saved → {args.log}")
