"""
avatar_engine.py
────────────────
Wrapper around SadTalker for talking avatar video generation.

SadTalker GitHub : https://github.com/OpenTalker/SadTalker
License          : MIT

This module:
  1. Checks that SadTalker is cloned and model weights are present.
  2. Calls SadTalker's inference.py via subprocess (avoids dependency hell).
  3. Returns the path to the generated MP4.
  4. Falls back to a silent-video stub when SadTalker is unavailable
     (useful for CI / environments without GPU).

Setup
-----
    git clone https://github.com/OpenTalker/SadTalker.git
    # download weights per setup.md
    export SADTALKER_ROOT=/path/to/SadTalker
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Optional

# ─── SadTalker root (override via env var or constructor) ─────────────────────
_DEFAULT_SADTALKER_ROOT = Path(__file__).parent / "SadTalker"
SADTALKER_ROOT = Path(os.environ.get("SADTALKER_ROOT", str(_DEFAULT_SADTALKER_ROOT)))


def _check_sadtalker() -> bool:
    """Return True if SadTalker looks properly installed."""
    inference_script = SADTALKER_ROOT / "inference.py"
    weights_dir = SADTALKER_ROOT / "checkpoints"
    return inference_script.exists() and weights_dir.exists()


def _check_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None


# ─── Stub video generation (fallback, no GPU required) ───────────────────────
def _generate_stub_video(
    image_path: str,
    audio_path: str,
    out_path: str,
) -> str:
    """
    Produce a minimal MP4 by combining the avatar image with the audio.
    This is a quality placeholder — not a talking head — used when SadTalker
    is unavailable.
    """
    if not _check_ffmpeg():
        raise RuntimeError("FFmpeg not found. Install it first (see setup.md).")

    # looping image + audio → mp4
    cmd = [
        "ffmpeg", "-y",
        "-loop", "1",
        "-i", image_path,
        "-i", audio_path,
        "-c:v", "libx264",
        "-tune", "stillimage",
        "-c:a", "aac",
        "-b:a", "192k",
        "-pix_fmt", "yuv420p",
        "-shortest",
        "-vf", "scale=512:512",
        out_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg stub video failed:\n{result.stderr}")
    return out_path


# ─── SadTalker invocation ─────────────────────────────────────────────────────
def generate_talking_avatar(
    image_path: str,
    audio_path: str,
    out_path: str,
    sadtalker_root: Optional[str] = None,
    still: bool = False,
    preprocess: str = "crop",
    size: int = 256,
    device: str = "auto",
    extra_args: Optional[list[str]] = None,
) -> dict:
    """
    Generate a talking avatar video from a still image and audio file.

    Parameters
    ----------
    image_path      : Path to the source avatar image (JPG or PNG).
    audio_path      : Path to the driving audio (WAV or MP3).
    out_path        : Where to write the output MP4.
    sadtalker_root  : Override SADTALKER_ROOT env var.
    still           : If True, use SadTalker --still flag (less head motion).
    preprocess      : SadTalker preprocess mode: 'crop' | 'resize' | 'full'.
    size            : Output resolution (256 or 512).
    device          : 'auto' | 'cuda' | 'cpu'.
    extra_args      : Additional CLI args passed straight to inference.py.

    Returns
    -------
    dict with keys: video_path, generation_time_seconds, method, sadtalker_used
    """
    import shutil

    root = Path(sadtalker_root) if sadtalker_root else SADTALKER_ROOT
    out_path = str(Path(out_path).resolve())
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)

    t0 = time.time()

    # ── Check SadTalker availability ─────────────────────────────────────────
    if not (root / "inference.py").exists():
        print(
            f"[avatar] SadTalker not found at {root}. "
            "Using stub video (still image + audio). "
            "Follow setup.md to install SadTalker for real lip-sync."
        )
        _generate_stub_video(image_path, audio_path, out_path)
        elapsed = round(time.time() - t0, 2)
        return {
            "video_path": out_path,
            "generation_time_seconds": elapsed,
            "method": "stub_ffmpeg",
            "sadtalker_used": False,
        }

    # ── Determine device ──────────────────────────────────────────────────────
    if device == "auto":
        try:
            import torch
            device = "cuda" if torch.cuda.is_available() else "cpu"
        except ImportError:
            device = "cpu"

    # SadTalker writes its output to a result folder; we'll move it afterward.
    result_dir = Path(out_path).parent / "_sadtalker_tmp"
    result_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable,
        str(root / "inference.py"),
        "--driven_audio", str(Path(audio_path).resolve()),
        "--source_image", str(Path(image_path).resolve()),
        "--result_dir", str(result_dir),
        "--preprocess", preprocess,
        "--size", str(size),
        "--device", device,
    ]
    if still:
        cmd.append("--still")
    if extra_args:
        cmd.extend(extra_args)

    print(f"[avatar] Running SadTalker on {device}...")
    print(f"[avatar] Command: {' '.join(cmd)}")

    env = os.environ.copy()
    env["PYTHONPATH"] = str(root)

    result = subprocess.run(
        cmd,
        capture_output=False,   # stream output live
        cwd=str(root),
        env=env,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"SadTalker inference failed (exit {result.returncode}). "
            "Check the output above for details."
        )

    # ── Find output file ──────────────────────────────────────────────────────
    mp4_files = sorted(result_dir.rglob("*.mp4"), key=lambda p: p.stat().st_mtime)
    if not mp4_files:
        raise RuntimeError(
            "SadTalker did not produce an MP4. Check the result directory: "
            + str(result_dir)
        )

    generated = mp4_files[-1]
    shutil.move(str(generated), out_path)
    shutil.rmtree(result_dir, ignore_errors=True)

    elapsed = round(time.time() - t0, 2)
    print(f"[avatar] Done → {out_path}  ({elapsed}s)")

    return {
        "video_path": out_path,
        "generation_time_seconds": elapsed,
        "method": f"sadtalker_{preprocess}_{size}px_{device}",
        "sadtalker_used": True,
    }


# ─── Baseline helper (Task 2) ─────────────────────────────────────────────────
def generate_baseline_videos(
    image_path: str,
    sample_audio_path: str,
    output_dir: str = "outputs",
    sadtalker_root: Optional[str] = None,
) -> list[dict]:
    """
    Generate three baseline videos (5s, 10s, 20s) from a sample audio file.

    The audio file is trimmed/padded with FFmpeg to produce three clips.
    """
    import subprocess

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    durations = {"5s": 5, "10s": 10, "20s": 20}
    results = []

    for label, dur in durations.items():
        trimmed_audio = output_dir / f"_baseline_audio_{label}.wav"
        out_video = output_dir / f"baseline_{label}.mp4"

        # Trim or loop the sample audio to the target duration
        cmd = [
            "ffmpeg", "-y",
            "-stream_loop", "-1",
            "-i", sample_audio_path,
            "-t", str(dur),
            "-ar", "16000",
            "-ac", "1",
            str(trimmed_audio),
        ]
        subprocess.run(cmd, capture_output=True, check=True)

        info = generate_talking_avatar(
            image_path=image_path,
            audio_path=str(trimmed_audio),
            out_path=str(out_video),
            sadtalker_root=sadtalker_root,
        )
        info["label"] = label
        info["duration_seconds"] = dur
        results.append(info)
        print(f"[baseline] {label}: {info['generation_time_seconds']}s → {out_video}")

    return results
