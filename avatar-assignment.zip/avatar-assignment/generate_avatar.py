#!/usr/bin/env python3
"""
generate_avatar.py
──────────────────
End-to-end AI Avatar Conversation pipeline.

Usage
-----
    python generate_avatar.py \\
        --image samples/avatar.jpg \\
        --user-text "Why are you silent?" \\
        --emotion confident \\
        --output outputs/avatar_response.mp4

    # With explicit TTS provider and debug output
    python generate_avatar.py \\
        --image samples/avatar.jpg \\
        --user-text "Tell me something intense." \\
        --emotion intense \\
        --output outputs/avatar_response.mp4 \\
        --tts-provider edge \\
        --debug

    # Run baseline Task-2 videos
    python generate_avatar.py --baseline --image samples/avatar.jpg

    # Run Task-3 TTS demo
    python generate_avatar.py --tts-demo

    # Run Task-4 conversation demo (3 turns, no video)
    python generate_avatar.py --conversation-demo

Full pipeline
─────────────
  User Text
    → AI Response Generation  (conversation_engine.py)
    → Emotion Mapping          (emotion_mapping.json)
    → Text-to-Speech Audio     (tts_engine.py)
    → Talking Avatar Video     (avatar_engine.py / SadTalker)
    → Save Output Video + Log
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

# ─── Colour helpers (optional, degrades gracefully) ──────────────────────────
try:
    from colorama import Fore, Style, init as _cinit
    _cinit(autoreset=True)
    def _c(text: str, colour: str) -> str:
        return colour + str(text) + Style.RESET_ALL
except ImportError:
    def _c(text: str, colour: str) -> str:  # type: ignore[misc]
        return str(text)
    class Fore:  # type: ignore[no-redef]
        GREEN = CYAN = YELLOW = RED = MAGENTA = ""

# ─── Project imports ──────────────────────────────────────────────────────────
from conversation_engine import ConversationEngine, VALID_EMOTIONS, detect_emotion
from tts_engine import synthesize as tts_synthesize
from avatar_engine import generate_talking_avatar, generate_baseline_videos


# ─── Banner ───────────────────────────────────────────────────────────────────
def _banner() -> None:
    print(_c("\n╔══════════════════════════════════════════╗", Fore.CYAN))
    print(_c("║   AI Avatar Conversation Pipeline v1.0   ║", Fore.CYAN))
    print(_c("╚══════════════════════════════════════════╝\n", Fore.CYAN))


# ─── Argument parser ──────────────────────────────────────────────────────────
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="AI Avatar Conversation — end-to-end CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # Main required args
    p.add_argument("--image", default="samples/avatar.jpg",
                   help="Path to static avatar image (JPG/PNG).")
    p.add_argument("--user-text", default="",
                   help="User message to feed into the avatar conversation.")
    p.add_argument("--emotion", default="neutral",
                   choices=VALID_EMOTIONS + ["auto"],
                   help="Emotion label (or 'auto' to detect from user text).")
    p.add_argument("--output", default="outputs/avatar_response.mp4",
                   help="Output video path (.mp4).")

    # Optional overrides
    p.add_argument("--tts-provider", default="edge", choices=["edge", "gtts", "pyttsx3"],
                   help="TTS engine to use.")
    p.add_argument("--avatar-model", default="sadtalker",
                   help="Avatar model name (for metadata; currently only SadTalker supported).")
    p.add_argument("--voice", default="",
                   help="Override TTS voice name (Edge TTS voice string).")
    p.add_argument("--api-key", default="",
                   help="OpenAI API key. Falls back to OPENAI_API_KEY env var, then rule-based.")
    p.add_argument("--llm-model", default="gpt-4o-mini",
                   help="LLM model name for response generation.")
    p.add_argument("--log", default="outputs/conversation_log.json",
                   help="Path to conversation log JSON.")
    p.add_argument("--sadtalker-root", default="",
                   help="Path to SadTalker repo root (overrides SADTALKER_ROOT env var).")
    p.add_argument("--debug", action="store_true",
                   help="Print verbose debug output.")

    # Mode switches
    p.add_argument("--baseline", action="store_true",
                   help="[Task 2] Generate baseline 5s/10s/20s avatar videos.")
    p.add_argument("--tts-demo", action="store_true",
                   help="[Task 3] Run TTS demo with the sample text.")
    p.add_argument("--conversation-demo", action="store_true",
                   help="[Task 4] Run 3-turn conversation demo (no video generation).")

    return p


# ─── Task modes ──────────────────────────────────────────────────────────────
def run_baseline(args: argparse.Namespace) -> None:
    """Task 2: generate baseline_5s.mp4, baseline_10s.mp4, baseline_20s.mp4."""
    print(_c("\n[Task 2] Baseline avatar generation", Fore.YELLOW))
    sample_audio = "samples/sample_audio.wav"
    if not Path(sample_audio).exists():
        # generate a short beep as placeholder if no sample audio present
        _generate_placeholder_audio(sample_audio, duration=3)

    results = generate_baseline_videos(
        image_path=args.image,
        sample_audio_path=sample_audio,
        output_dir="outputs",
        sadtalker_root=args.sadtalker_root or None,
    )
    print(_c("\n[Task 2] Results:", Fore.GREEN))
    for r in results:
        print(f"  {r['label']:5s} → {r['video_path']}  [{r['generation_time_seconds']}s]")


def run_tts_demo(args: argparse.Namespace) -> None:
    """Task 3: synthesize the required sample text and generate TTS avatar video."""
    SAMPLE_TEXT = (
        "I do not speak to impress people. "
        "I speak only when silence becomes heavier than truth."
    )
    print(_c("\n[Task 3] TTS integration demo", Fore.YELLOW))
    print(f"  Text: {SAMPLE_TEXT}")

    audio_out = "outputs/tts_audio.wav"
    tts_synthesize(
        text=SAMPLE_TEXT,
        emotion="neutral",
        out_path=audio_out,
        provider=args.tts_provider,
    )
    print(_c(f"  Audio saved → {audio_out}", Fore.GREEN))

    video_out = "outputs/tts_avatar_output.mp4"
    result = generate_talking_avatar(
        image_path=args.image,
        audio_path=audio_out,
        out_path=video_out,
        sadtalker_root=args.sadtalker_root or None,
    )
    print(_c(f"  Video saved → {video_out}  [{result['generation_time_seconds']}s]", Fore.GREEN))


def run_conversation_demo(args: argparse.Namespace) -> None:
    """Task 4: 3-turn conversation demo (response + TTS only, no video)."""
    print(_c("\n[Task 4] Conversation demo (3 turns)", Fore.YELLOW))
    engine = ConversationEngine(log_path=args.log, api_key=args.api_key, model=args.llm_model)

    turns = [
        ("Who are you?", "neutral"),
        ("Why do you look serious?", "intense"),
        ("Tell me something emotional in one sentence.", "sad"),
    ]
    for user_msg, emotion in turns:
        entry = engine.respond(user_msg, emotion=emotion)
        print(f"\n  User   : {user_msg}")
        print(f"  Avatar : {_c(entry['response'], Fore.CYAN)}")
        print(f"  Emotion: {entry['emotion']}  ({entry['method']})")

    print(_c(f"\n  Log → {args.log}", Fore.GREEN))


# ─── Full pipeline ────────────────────────────────────────────────────────────
def run_full_pipeline(args: argparse.Namespace) -> None:
    """Main pipeline: text → response → TTS → avatar video."""
    _banner()

    # ── Validate inputs ───────────────────────────────────────────────────────
    if not args.user_text:
        print(_c("[error] --user-text is required for full pipeline mode.", Fore.RED))
        sys.exit(1)

    image_path = Path(args.image)
    if not image_path.exists():
        print(_c(f"[error] Avatar image not found: {image_path}", Fore.RED))
        sys.exit(1)

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.log).parent.mkdir(parents=True, exist_ok=True)

    t_total = time.time()

    # ── Step 1: AI Response Generation ───────────────────────────────────────
    emotion = args.emotion
    if emotion == "auto":
        emotion = detect_emotion(args.user_text)
        print(f"[auto-emotion] Detected: {emotion}")

    print(_c(f"\n[1/4] Generating AI response (emotion: {emotion})...", Fore.CYAN))
    engine = ConversationEngine(log_path=args.log, api_key=args.api_key, model=args.llm_model)
    entry = engine.respond(args.user_text, emotion=emotion)
    response_text = entry["response"]
    print(f"      User  : {args.user_text}")
    print(f"      Avatar: {_c(response_text, Fore.GREEN)}")

    # ── Step 2: Text-to-Speech ────────────────────────────────────────────────
    audio_stem = Path(args.output).stem
    audio_path = str(Path("outputs") / f"{audio_stem}_audio.wav")
    print(_c(f"\n[2/4] Synthesizing speech ({args.tts_provider})...", Fore.CYAN))
    tts_synthesize(
        text=response_text,
        emotion=emotion,
        out_path=audio_path,
        provider=args.tts_provider,
        tts_params=engine.get_tts_params(emotion),
    )
    print(f"      Audio → {audio_path}")

    # ── Step 3: Talking Avatar Video ─────────────────────────────────────────
    print(_c(f"\n[3/4] Generating talking avatar video...", Fore.CYAN))
    av_result = generate_talking_avatar(
        image_path=str(image_path),
        audio_path=audio_path,
        out_path=args.output,
        sadtalker_root=args.sadtalker_root or None,
    )
    print(f"      Video → {av_result['video_path']}  [{av_result['generation_time_seconds']}s]")

    # ── Step 4: Update conversation log ──────────────────────────────────────
    print(_c(f"\n[4/4] Saving conversation log...", Fore.CYAN))
    entry["audio_path"] = audio_path
    entry["video_path"] = av_result["video_path"]
    entry["generation_time_video_seconds"] = av_result["generation_time_seconds"]
    entry["avatar_method"] = av_result["method"]
    engine._save_history()
    print(f"      Log   → {args.log}")

    # ── Summary ───────────────────────────────────────────────────────────────
    total = round(time.time() - t_total, 2)
    print(_c(f"\n✓ Done in {total}s", Fore.GREEN))
    print(_c(f"  Output video : {av_result['video_path']}", Fore.GREEN))
    print(_c(f"  Audio        : {audio_path}", Fore.GREEN))
    print(_c(f"  Log          : {args.log}\n", Fore.GREEN))


# ─── Placeholder audio helper ─────────────────────────────────────────────────
def _generate_placeholder_audio(path: str, duration: int = 5) -> None:
    """Generate a silent WAV file for use when no sample audio is present."""
    import subprocess
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["ffmpeg", "-y", "-f", "lavfi", "-i",
         f"anullsrc=r=16000:cl=mono:d={duration}", path],
        capture_output=True,
    )


# ─── Entry point ─────────────────────────────────────────────────────────────
def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.debug:
        print("[debug] Arguments:", vars(args))

    try:
        if args.baseline:
            run_baseline(args)
        elif args.tts_demo:
            run_tts_demo(args)
        elif args.conversation_demo:
            run_conversation_demo(args)
        else:
            run_full_pipeline(args)
    except KeyboardInterrupt:
        print("\n[interrupted]")
        sys.exit(0)
    except Exception as exc:
        print(_c(f"\n[error] {exc}", Fore.RED))
        if args.debug:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
