# AI Avatar Conversation Pipeline

> Internship Assignment — AI/ML Intern · Talking Avatar / Generative AI / Conversation Systems

A fully runnable proof-of-concept that accepts a user message and produces a talking avatar video response.

```
User Message
  → AI Response Generation  (OpenAI API / rule-based fallback)
  → Emotion Mapping          (emotion_mapping.json)
  → Text-to-Speech Audio     (Edge TTS / gTTS fallback)
  → Talking Avatar Video     (SadTalker)
  → Final Output MP4
```

---

## Quick Start

```bash
# 1. Clone and enter the project
git clone <repo-url> avatar-assignment && cd avatar-assignment

# 2. Create virtual environment
python3.10 -m venv venv && source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Add your avatar image (AI-generated / open-licence)
cp /path/to/your/portrait.jpg samples/avatar.jpg

# 5. Run the full pipeline
python generate_avatar.py \
    --image samples/avatar.jpg \
    --user-text "Why are you silent?" \
    --emotion confident \
    --output outputs/avatar_response.mp4
```

**Full setup instructions** (SadTalker weights, FFmpeg, GPU) → [setup.md](setup.md)

---

## All Commands

### Full pipeline (all 6 tasks)
```bash
python generate_avatar.py \
    --image samples/avatar.jpg \
    --user-text "Why are you serious?" \
    --emotion intense \
    --output outputs/avatar_response.mp4 \
    --tts-provider edge \
    --debug
```

### Task 2 — Baseline videos (5s / 10s / 20s)
```bash
python generate_avatar.py --baseline --image samples/avatar.jpg
```

### Task 3 — TTS demo
```bash
python generate_avatar.py --tts-demo
```

### Task 4 — Conversation demo (3 turns, no video)
```bash
python generate_avatar.py --conversation-demo
```

### Task 4 — Conversation engine standalone
```bash
python conversation_engine.py
```

### Bonus — Start FastAPI server
```bash
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
# Then open: http://localhost:8000/docs
```

### Bonus — Sample API call
```bash
curl -X POST http://localhost:8000/generate-avatar \
     -H "Content-Type: application/json" \
     -d '{
           "image_path": "samples/avatar.jpg",
           "user_text": "Why are you serious?",
           "emotion": "intense"
         }'
```

---

## CLI Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--image` | Yes | `samples/avatar.jpg` | Path to avatar image |
| `--user-text` | Yes* | — | User message |
| `--emotion` | No | `neutral` | Emotion label (or `auto`) |
| `--output` | No | `outputs/avatar_response.mp4` | Output video path |
| `--tts-provider` | No | `edge` | `edge` / `gtts` / `pyttsx3` |
| `--api-key` | No | env var | OpenAI API key |
| `--llm-model` | No | `gpt-4o-mini` | LLM model name |
| `--sadtalker-root` | No | `./SadTalker` | Path to SadTalker repo |
| `--debug` | No | — | Verbose output |
| `--baseline` | No | — | Run Task 2 baseline generation |
| `--tts-demo` | No | — | Run Task 3 TTS demo |
| `--conversation-demo` | No | — | Run Task 4 conversation demo |

---

## Tech Stack

| Component | Choice | Reason |
|---|---|---|
| Talking avatar | SadTalker | Open-source, MIT licence, good lip-sync on CPU/GPU |
| TTS (primary) | Edge TTS | Free, no API key, rich voice styles (cheerful/sad/angry) |
| TTS (fallback) | gTTS | Free, no API key, runs without Edge TTS |
| AI response | OpenAI API | High quality; falls back to rule-based if no key |
| API layer | FastAPI | Fast, auto-docs, async support |
| Video/audio | FFmpeg + pydub | Standard, stable, widely available |

---

## Repository Structure

```
avatar-assignment/
├── README.md
├── setup.md
├── requirements.txt
├── generate_avatar.py       ← Main CLI entry point (Task 6)
├── conversation_engine.py   ← AI response + logging (Task 4)
├── tts_engine.py            ← TTS abstraction layer (Task 3)
├── avatar_engine.py         ← SadTalker wrapper (Tasks 2/3/6)
├── emotion_mapping.json     ← Emotion configuration (Task 5)
├── app.py                   ← FastAPI service (Bonus)
├── samples/
│   ├── avatar.jpg           ← Your avatar portrait
│   └── sample_audio.wav     ← Short sample audio for baseline
├── outputs/
│   ├── baseline_5s.mp4
│   ├── baseline_10s.mp4
│   ├── baseline_20s.mp4
│   ├── tts_audio.wav
│   ├── tts_avatar_output.mp4
│   ├── avatar_response.mp4
│   └── conversation_log.json
└── report/
    └── technical_report.md
```

---

## Supported Emotions

| Emotion | TTS Style | Speed | Prompt Tone |
|---|---|---|---|
| neutral | general | 1.0× | calm and measured |
| happy | cheerful | 1.1× | warm and upbeat |
| sad | sad | 0.9× | melancholic, reflective |
| angry | angry | 1.15× | assertive, direct |
| confident | firm (→ neutral) | 1.0× | strong, decisive |
| teasing | cheerful | 1.05× | playful, witty |
| intense | shouting | 0.95× | grave, urgent |

Emotion effects are applied to: TTS voice style, TTS speed, LLM response tone, and output metadata. SadTalker does not expose per-emotion head motion control via its standard CLI.

---

## Fallback Modes

- **No OpenAI API key**: rule-based responses used automatically.
- **No SadTalker weights**: stub video (still image + audio) generated with FFmpeg.
- **Edge TTS offline**: automatically falls back to gTTS.
- **No GPU**: SadTalker runs on CPU (slower, same quality).

---

## Ethics and Asset Rules

- Avatar image must be AI-generated, self-owned, or open-licence. No celebrity faces.
- No cloned voices or copyrighted dialogues.
- No real person identity used without permission.

---

## Technical Report

See [report/technical_report.md](report/technical_report.md) for full answers to all 17 required questions.
